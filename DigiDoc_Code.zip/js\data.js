// Mock data for DigiDoc

const DOCTORS = [
    {
        id: 'doc1',
        name: 'Dr. Sarah Jenkins',
        specialty: 'General Practitioner',
        location: 'Downtown Medical Center (1.2 miles)',
        rating: 4.8,
        reviews: 124,
        pros: ['Very empathetic with older patients', 'Short wait times', 'Highly rated for accurate diagnosis'],
        cons: ['Limited availability on weekends', 'Clinic parking can be difficult']
    },
    {
        id: 'doc2',
        name: 'Dr. Marcus Chen',
        specialty: 'Cardiologist',
        location: 'Westside Heart Clinic (3.5 miles)',
        rating: 4.9,
        reviews: 89,
        pros: ['Top specialist in the region', 'State-of-the-art facility', 'Accepts most major insurances'],
        cons: ['Long waiting list for new patients', 'Can seem rushed during consultations']
    },
    {
        id: 'doc3',
        name: 'Dr. Emily Patel',
        specialty: 'Internal Medicine',
        location: 'Sunrise Health Group (2.0 miles)',
        rating: 4.6,
        reviews: 210,
        pros: ['Excellent at explaining complex conditions', 'Offers telehealth appointments', 'Friendly staff'],
        cons: ['Sometimes runs behind schedule', 'Hard to reach directly by phone']
    },
    {
        id: 'doc4',
        name: 'Dr. Robert Sullivan',
        specialty: 'Neurologist',
        location: 'Central Neurological (4.1 miles)',
        rating: 4.7,
        reviews: 56,
        pros: ['Extremely thorough examinations', 'Great at managing chronic conditions', 'Quick test results'],
        cons: ['Strict cancellation policy', 'Office is slightly outdated']
    }
];

const HEALTH_BOT_KNOWLEDGE = {
    greeting: "Hello. I am the DigiDoc AI Symptom Checker. I am trained on comprehensive data from the NHS, CareHospitals, and health departments. To provide an accurate assessment, I need some information. Could you please share your **Age** and **Gender**? (Leave blank if you prefer not to share).",
    followUp1: "Thank you. Now, do you have any **past diseases** or chronic conditions, and what is your **vaccination status**?",
    followUp2: "Got it. Have you seen any **doctors for diagnosing** this issue recently?",
    symptomsAsk: "Thank you for the background. Please describe your current symptoms in as much detail as possible.",
    diagnosisMock: "Based on your symptoms and the medical knowledge base (NHS, HealthyWA, DPH Illinois), your symptoms could be consistent with a viral upper respiratory infection (common cold) or mild seasonal allergies. However, I am an AI and this is not a definitive medical diagnosis.\n\nI recommend seeing a local General Practitioner for a proper examination. Would you like me to suggest some local doctors?"
};
