// Main App Logic

const app = {
    currentRoute: 'home',

    init() {
        this.navigate('home');
        
        // Initial nav bot greeting timeout to simulate helpfulness
        setTimeout(() => {
            if (document.getElementById('nav-bot-widget').classList.contains('nav-bot-closed')) {
                // Flash tooltip
                const toggle = document.getElementById('nav-bot-toggle');
                toggle.style.transform = 'scale(1.1)';
                setTimeout(() => toggle.style.transform = '', 300);
            }
        }, 3000);
    },

    navigate(route) {
        this.currentRoute = route;
        const main = document.getElementById('main-content');
        
        // Update nav buttons
        document.querySelectorAll('.nav-btn').forEach(btn => {
            if (!btn.classList.contains('primary')) {
                btn.style.color = 'var(--text-secondary)';
                btn.style.background = 'transparent';
            }
        });

        // Render view
        if (route === 'home') {
            main.innerHTML = Components.Home();
            navBot.setContext('home');
        } else if (route === 'symptom-checker') {
            main.innerHTML = Components.SymptomChecker();
            healthBot.init();
            navBot.setContext('symptom-checker');
        } else if (route === 'find-doctors') {
            main.innerHTML = Components.FindDoctors();
            doctorFinder.init();
            navBot.setContext('find-doctors');
            
            // Special Navigation Bot behavior on Find Doctors page
            setTimeout(() => {
                navBot.open();
                navBot.addBotMessage("I see you're looking for doctors. I can help analyze the pros and cons of the doctors listed here based on Google research. Just let me know which one you are interested in!");
            }, 1000);
        }
    }
};

const navBot = {
    isOpen: false,
    context: 'home',

    toggle() {
        const widget = document.getElementById('nav-bot-widget');
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            widget.classList.remove('nav-bot-closed');
            document.getElementById('nav-bot-input').focus();
        } else {
            widget.classList.add('nav-bot-closed');
        }
    },
    
    open() {
        if (!this.isOpen) this.toggle();
    },

    setContext(route) {
        this.context = route;
    },

    handleQuickAction(action) {
        if (action === 'symptoms') {
            app.navigate('symptom-checker');
            this.addBotMessage("I've taken you to the AI Health Checker.");
        } else if (action === 'doctors') {
            app.navigate('find-doctors');
            this.addBotMessage("Here is the Find Doctors page. Let me know if you want me to analyze any doctor's pros and cons!");
        }
    },

    handleInput(e) {
        if (e.key === 'Enter') {
            this.sendMsg();
        }
    },

    sendMsg() {
        const input = document.getElementById('nav-bot-input');
        const text = input.value.trim();
        if (!text) return;

        this.addUserMessage(text);
        input.value = '';

        this.showTyping();
        
        setTimeout(() => {
            this.hideTyping();
            this.processMessage(text.toLowerCase());
        }, 1000);
    },

    processMessage(text) {
        if (this.context === 'find-doctors') {
            // Check if they are asking about a doctor
            const doc = DOCTORS.find(d => text.includes(d.name.toLowerCase().split(' ')[1]) || text.includes(d.id));
            if (doc) {
                this.analyzeDoctor(doc);
                return;
            } else if (text.includes('pro') || text.includes('con') || text.includes('research')) {
                this.addBotMessage("Sure! Please tell me which doctor's name you'd like me to research (e.g., 'Dr. Jenkins' or 'Dr. Chen').");
                return;
            }
        }
        
        if (text.includes('symptom') || text.includes('sick')) {
            this.addBotMessage("It sounds like you need the Symptom Checker. Shall I take you there?");
            this.handleQuickAction('symptoms');
        } else if (text.includes('doctor') || text.includes('find')) {
            this.addBotMessage("I can take you to the Find Doctors page.");
            this.handleQuickAction('doctors');
        } else {
            this.addBotMessage("I'm here to help you navigate DigiDoc. You can ask me to go to the Symptom Checker, Find Doctors, or (if on the Doctors page) ask for pros and cons of a doctor.");
        }
    },

    analyzeDoctor(doc) {
        let msg = `<strong>${doc.name}</strong><br><br>Based on a quick Google research analysis, here are the pros and cons:<br><br>`;
        msg += `<strong style="color:var(--secondary)">Pros:</strong><ul>`;
        doc.pros.forEach(p => msg += `<li>${p}</li>`);
        msg += `</ul><br>`;
        msg += `<strong style="color:var(--danger)">Cons:</strong><ul>`;
        doc.cons.forEach(c => msg += `<li>${c}</li>`);
        msg += `</ul>`;
        this.addBotMessage(msg);
    },

    addUserMessage(text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'message user';
        msgDiv.textContent = text;
        this.appendMessage(msgDiv);
    },

    addBotMessage(html) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'message bot';
        msgDiv.innerHTML = html;
        this.appendMessage(msgDiv);
    },

    showTyping() {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'typing-indicator';
        msgDiv.id = 'nav-typing';
        msgDiv.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
        this.appendMessage(msgDiv);
    },

    hideTyping() {
        const el = document.getElementById('nav-typing');
        if (el) el.remove();
    },

    appendMessage(el) {
        const container = document.getElementById('nav-bot-messages');
        container.appendChild(el);
        container.scrollTop = container.scrollHeight;
    }
};

const healthBot = {
    step: 0,

    init() {
        this.step = 0;
    },

    handleInput(e) {
        if (e.key === 'Enter') {
            this.sendMsg();
        }
    },

    sendMsg() {
        const input = document.getElementById('health-chat-input');
        const text = input.value.trim();
        
        // Allow blank input as requested "assume they do not know or do not want to share"
        const displayValue = text === '' ? '<em>(Skipped/Not shared)</em>' : text;
        
        this.addUserMessage(displayValue);
        input.value = '';

        this.showTyping();
        
        setTimeout(() => {
            this.hideTyping();
            this.progressStep();
        }, 1200);
    },

    progressStep() {
        this.step++;
        
        if (this.step === 1) {
            this.addBotMessage(HEALTH_BOT_KNOWLEDGE.followUp1);
        } else if (this.step === 2) {
            this.addBotMessage(HEALTH_BOT_KNOWLEDGE.followUp2);
        } else if (this.step === 3) {
            this.addBotMessage(HEALTH_BOT_KNOWLEDGE.symptomsAsk);
        } else if (this.step === 4) {
            this.addBotMessage(HEALTH_BOT_KNOWLEDGE.diagnosisMock);
            
            // Add doctor recommendation buttons
            setTimeout(() => {
                const btnHtml = `
                    <div style="margin-top: 1rem; display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        <button class="btn btn-primary" style="padding: 0.5rem 1rem; font-size: 0.9rem;" onclick="app.navigate('find-doctors')">
                            Find Local Doctors
                        </button>
                    </div>
                `;
                this.addBotMessage(btnHtml);
            }, 500);
        } else {
            this.addBotMessage("If your symptoms worsen, please visit an emergency room immediately.");
        }
    },

    addUserMessage(html) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'message user';
        msgDiv.innerHTML = html;
        this.appendMessage(msgDiv);
    },

    addBotMessage(html) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'message bot';
        msgDiv.innerHTML = html;
        this.appendMessage(msgDiv);
    },

    showTyping() {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'typing-indicator';
        msgDiv.id = 'health-typing';
        msgDiv.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
        this.appendMessage(msgDiv);
    },

    hideTyping() {
        const el = document.getElementById('health-typing');
        if (el) el.remove();
    },

    appendMessage(el) {
        const container = document.getElementById('health-chat-messages');
        container.appendChild(el);
        container.scrollTop = container.scrollHeight;
    }
};

const doctorFinder = {
    init() {
        this.renderDoctors(DOCTORS);
    },

    search() {
        const input = document.getElementById('location-input').value.trim();
        const container = document.getElementById('doctor-results');
        
        container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 2rem;"><div class="typing-indicator" style="margin:0 auto;"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div><p style="margin-top:1rem; color: var(--text-secondary);">Searching databases...</p></div>';
        
        setTimeout(() => {
            this.renderDoctors(DOCTORS); // In a real app, filter based on location
        }, 1000);
    },

    renderDoctors(docs) {
        const container = document.getElementById('doctor-results');
        container.innerHTML = '';
        docs.forEach(doc => {
            container.innerHTML += Components.DoctorCard(doc);
        });
    },

    viewDoctor(id) {
        navBot.open();
        const doc = DOCTORS.find(d => d.id === id);
        navBot.addBotMessage(`You clicked on <strong>${doc.name}</strong>. Let me analyze their pros and cons for you...`);
        navBot.showTyping();
        
        setTimeout(() => {
            navBot.hideTyping();
            navBot.analyzeDoctor(doc);
        }, 1500);
    }
};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});
